# mJARVIS

**mJARVIS** is a personal AI assistant project built from the JARVIS OS V.2 codebase. The project is being developed web-first, with a responsive experience for mobile and desktop browsers, while retaining the desktop application as a later product surface.

> This repository is a modified derivative of JARVIS OS V.2. See [LICENSE](LICENSE) for the applicable MIT license and preserve the original copyright and license notices.

## Product direction

- **Web first:** Next.js client with a FastAPI service.
- **Mobile and desktop browsers:** responsive interface, shared account and hosted session.
- **Desktop app:** retain and progressively rebrand the existing Python/PyQt6 application after the web experience is stable.
- **AI:** Gemini Live voice and text experience.
- **Hosted data:** PostgreSQL for user-scoped data and Redis for request quotas, as configured by the API.

## Repository structure

- `web/` — Next.js web application.
- `api/` — FastAPI hosted API, authentication, database and WebSocket endpoints.
- `core/`, `agent/`, `actions/`, `memory/` — assistant runtime, planning, tools and memory.
- `main.py`, `ui.py` — existing desktop application entry points.
- `tests/` — automated tests and QA support.

## Web development

Requirements: Python 3.11+, Node.js compatible with the installed Next.js version, npm, PostgreSQL and Redis for the complete hosted stack.

```bash
# From the repository root
cp .env.example .env
# Configure the required secrets and service URLs in .env

# Start API, database, Redis and web client
docker compose up --build
```

Open `http://localhost:3000`. For direct development, start the API with `uvicorn api.server:app --reload`, then run the web client:

```bash
cd web
cp .env.example .env.local
npm ci
npm run dev
```

Set `NEXT_PUBLIC_API_URL` and `NEXT_PUBLIC_WS_URL` to the API's reachable HTTP and WebSocket URLs. In production, configure `DATABASE_URL`, `REDIS_URL`, `JWT_SECRET`, `JARVIS_ENCRYPTION_KEY` and `CORS_ORIGINS` on the API host. Configure the public API URLs on the Next.js host. Never commit `.env`, `.env.local`, API keys, tokens or private user data.

## Validation

```bash
cd web
npm run typecheck
npm run lint
npm run build
```

Run the Python test suite from the repository root using the project's documented environment and installed dependencies. Some desktop capabilities require operating-system permissions and cannot be fully validated in a headless hosted environment.

## Roadmap

1. Stabilize and validate the responsive web client.
2. Complete product identity, onboarding, security and user-scoped memory.
3. Validate deployment and operational monitoring.
4. Rebrand and package the desktop application.
5. Evaluate a dedicated mobile app only after the responsive web experience is stable.

## License and attribution

This project retains the original MIT license. Keep the original copyright notice and license text in redistributed copies and substantial portions of the software.
