# mJARVIS Brand

- Product name: **mJARVIS**
- Positioning: personal AI assistant and workspace
- Primary experience: responsive web app
- Future surfaces: desktop application; mobile-native app only if later justified
- Visual direction: deep navy/near-black surfaces, cyan energy accents, clear typography, restrained motion
- Voice: confident, useful, calm and direct

The existing project contains legacy JARVIS names in Python modules, internal API configuration and desktop entry points. These are intentionally not mass-renamed in this first pass because they may be referenced by imports, persisted settings, scripts or deployment configuration. Rebrand those layers incrementally with tests.
