# mJARVIS Product Direction

## Purpose

mJARVIS is a personal AI workspace that brings voice, text, reasoning and authorized tools into one coherent assistant. The initial release is a responsive web application that works on mobile and desktop browsers. The existing desktop client remains part of the codebase and will be rebranded after the web experience is stable.

## Primary users

People who want one assistant for conversation, research, writing, coding support, files and repeatable workflows.

## Product principles

1. Ship a dependable web experience before expanding platforms.
2. Voice and text are equal ways to interact.
3. Show only real system states and available capabilities.
4. Keep user data isolated and credentials protected.
5. Make mobile browser use a first-class responsive experience.
6. Add desktop packaging only after core web flows pass end-to-end tests.

## Product surfaces

- Phase 1: Next.js web application + FastAPI service.
- Phase 2: responsive polish, accessibility, security and deployment hardening.
- Phase 3: desktop application rebrand and packaging.
- Later: consider a dedicated mobile app if responsive web usage demonstrates a need.

## Non-goals for the first release

- Claiming capabilities that are not implemented or connected.
- Running computer-control actions without clear authorization.
- Storing API keys or personal data in browser-visible code.
