"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { Activity, ArrowUp, LogOut, Mic, MicOff, Radio, ShieldCheck, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reactor } from "@/components/reactor";
import { useJarvisSocket } from "@/hooks/use-jarvis-socket";
import { api, type Action, type User } from "@/lib/api";

export function JarvisConsole({ user, onSignOut }: { user: User; onSignOut: () => void }) {
  const live = useJarvisSocket();
  const [actions, setActions] = useState<Action[]>([]);
  const [draft, setDraft] = useState("");
  const logEnd = useRef<HTMLDivElement>(null);

  useEffect(() => { api<{ actions: Action[] }>("/actions").then((data) => setActions(data.actions)).catch(() => undefined); }, []);
  useEffect(() => { logEnd.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [live.messages]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (await live.sendText(draft)) setDraft("");
  }

  const connected = !["OFFLINE", "CONNECTING"].includes(live.state);

  return (
    <main className="console-shell">
      <header className="console-header">
        <div className="wordmark"><span className="wordmark-mark">M</span> mJARVIS <small>PERSONAL AI</small></div>
        <div className="header-state" aria-live="polite">
          {connected ? <Wifi size={14} /> : <WifiOff size={14} />}
          <span>{live.state}</span>
        </div>
        <div className="operator-menu"><span>{user.display_name}</span><Button variant="ghost" size="sm" onClick={onSignOut}><LogOut size={14} /> Sair</Button></div>
      </header>

      <div className="console-grid">
        <section className="mission-log" aria-labelledby="log-title">
          <div className="panel-heading"><div><p className="section-index">CANAL / PRINCIPAL</p><h2 id="log-title">Histórico de conversas</h2></div><Radio size={17} /></div>
          <div className="message-stream" aria-live="polite">
            {live.messages.length === 0 ? (
              <div className="empty-log"><span>Aguardando sua primeira instrução</span><p>Fale naturalmente ou digite um pedido. O mJARVIS mantém o contexto entre os dois modos de entrada.</p></div>
            ) : live.messages.map((message) => (
              <article key={message.id} className={`message message-${message.role}`}>
                <div><span>{message.role === "assistant" ? "mJARVIS" : message.role === "user" ? "VOCÊ" : "SISTEMA"}</span><time>{new Date(message.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</time></div>
                <p>{message.content}</p>
              </article>
            ))}
            <div ref={logEnd} />
          </div>
        </section>

        <section className="command-stage" aria-labelledby="command-title">
          <div className="state-caption"><span className="state-dot" /> NÚCLEO AO VIVO / {live.state}</div>
          <Reactor state={live.state} />
          <div className="voice-caption">
            <h1 id="command-title">{live.state === "SPEAKING" ? "Respondendo" : live.state === "THINKING" ? "Raciocinando" : live.state === "LISTENING" ? "Ouvindo" : live.state === "MUTED" ? "Voz pausada" : "Conectando"}</h1>
            <p>{live.transcript || (live.micActive ? "Microfone ativo. Pode falar." : "Canal de texto pronto. Ative o microfone para falar.")}</p>
          </div>
          <form className="command-composer" onSubmit={submit}>
            <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} placeholder="Digite sua instrução..." aria-label="Mensagem para mJARVIS" rows={2} />
            <Button type="button" variant={live.micActive ? "danger" : "secondary"} size="icon" disabled={!connected} aria-label={live.micActive ? "Silenciar microfone" : "Ativar microfone"} onClick={() => live.micActive ? live.stopMic() : live.startMic()}>
              {live.micActive ? <MicOff size={18} /> : <Mic size={18} />}
            </Button>
            <Button type="submit" size="icon" aria-label="Enviar instrução" disabled={!draft.trim() || !connected}><ArrowUp size={18} /></Button>
          </form>
          {live.error && <p className="console-error" role="alert">{live.error}</p>}
        </section>

        <aside className="systems-panel" aria-labelledby="systems-title">
          <div className="panel-heading"><div><p className="section-index">SISTEMA / AO VIVO</p><h2 id="systems-title">Estado operacional</h2></div><Activity size={17} /></div>
          <dl className="status-readout">
            <div><dt>Gemini Live</dt><dd data-on={connected}>{connected ? "CONECTADO" : "EM ESPERA"}</dd></div>
            <div><dt>Entrada de voz</dt><dd data-on={live.micActive}>{live.micActive ? "ATIVO" : "MUDO"}</dd></div>
            <div><dt>Isolamento de usuário</dt><dd data-on="true"><ShieldCheck size={13} /> ISOLADO</dd></div>
          </dl>
          {live.progress && (
            <section className="real-progress" aria-label={`Progresso: ${live.progress.kind}`}>
              <div><span>{live.progress.label}</span><b>{Math.round(live.progress.percent)}%</b></div>
              <div className="progress-track"><span style={{ transform: `scaleX(${live.progress.percent / 100})` }} /></div>
              <p>{live.progress.phase}</p>
            </section>
          )}
          <section className="capability-index">
            <div className="capability-heading"><span>Ferramentas disponíveis</span><b>{String(actions.length).padStart(2, "0")}</b></div>
            <ul>
              {actions.map((action) => <li key={action.name}><span>{action.name.replaceAll("_", " ")}</span><i /></li>)}
            </ul>
          </section>
        </aside>
      </div>
    </main>
  );
}
