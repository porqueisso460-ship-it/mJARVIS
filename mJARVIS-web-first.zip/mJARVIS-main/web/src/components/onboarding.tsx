"use client";

import { FormEvent, useState } from "react";
import { Check, ExternalLink, KeyRound, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api, type User } from "@/lib/api";

export function Onboarding({ user, onComplete, onSignOut }: { user: User; onComplete: () => void; onSignOut: () => void }) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const data = new FormData(event.currentTarget);
    try {
      await api("/me/gemini-key", {
        method: "POST",
        body: JSON.stringify({ api_key: data.get("api_key"), validate: true }),
      });
      onComplete();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível validar a chave");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="onboarding-shell">
      <header className="onboarding-header">
        <div className="wordmark"><span className="wordmark-mark">M</span> mJARVIS</div>
        <button className="text-button" onClick={onSignOut}>Usar outra conta</button>
      </header>
      <section className="onboarding-sequence">
        <div className="sequence-rail" aria-label="Progresso da configuração">
          <div className="sequence-step complete"><span><Check size={14} /></span><div><b>Identidade</b><small>{user.email}</small></div></div>
          <div className="sequence-line" />
          <div className="sequence-step active"><span>02</span><div><b>Gemini Live</b><small>Acesso privado ao modelo</small></div></div>
        </div>
        <div className="key-stage">
          <p className="section-index">CONFIGURAÇÃO / 02</p>
          <KeyRound className="stage-icon" size={28} />
          <h1>Conecte sua inteligência.</h1>
          <p>
            O mJARVIS usa sua chave da API Gemini para conversas por voz e raciocínio. A chave é criptografada no armazenamento e nunca é devolvida ao navegador.
          </p>
          <form onSubmit={submit} className="key-form">
            <label>Chave da API Gemini<Input name="api_key" type="password" autoComplete="off" required minLength={20} placeholder="Cole sua chave do Google AI Studio" /></label>
            {error && <p className="form-error" role="alert">{error}</p>}
            <Button disabled={pending} type="submit" className="w-full">
              <LockKeyhole size={16} /> {pending ? "Verificando com Gemini" : "Criptografar e iniciar"}
            </Button>
          </form>
          <a className="external-link" href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer">
            Abrir Google AI Studio <ExternalLink size={14} />
          </a>
        </div>
      </section>
    </main>
  );
}
